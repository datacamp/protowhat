from protowhat.checks.check_bash_history import (
    update_bash_history_info,
    get_bash_history,
    prepare_validation,
)
